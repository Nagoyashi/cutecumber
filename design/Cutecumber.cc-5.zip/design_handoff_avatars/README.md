# cutecumber · avatar expansion handoff (waves 1–3)

**What this is:** 36 new character avatars extending the original 12-avatar set
(`sprout, froggy, bun, boo, berry, shroom, matcha, moonbeam, blossom, whiskers,
riceball, twinkle`). Same construction system, ready to ship. Total set after
merge: **48**.

**Contents of this package:**

```
design_handoff_avatars/
├── README.md          ← this spec
├── preview.html       ← open in a browser to eyeball all 36 (relative paths)
└── avatars/           ← 36 final SVGs, filenames = canonical avatar names
```

---

## 1. Where files go

Copy `avatars/*.svg` into the same directory that serves the existing 12
avatar SVGs (repo equivalent of `production/avatars/` in the design project,
i.e. wherever `sprout.svg` lives — likely `app/static/avatars/`). Filenames
are canonical: **the avatar name is the filename** and is used as the DB
token `set:<name>` per the v1 design spec. Do not rename.

## 2. Roster (36 new)

Wave 1: `peachy` peach · `ducky` duckling · `honey` bear · `tako` octopus ·
`waddle` penguin · `sealie` seal · `lottie` axolotl · `bumble` bee ·
`flan` caramel pudding · `dango` dango skewer · `sunny` fried egg (sleepy) ·
`melly` watermelon

Wave 2: `pup` puppy · `kit` fox · `hammy` hamster · `bamboo` panda ·
`hoot` owl · `puff` cloud · `splash` whale · `pinchy` crab · `shelly` snail ·
`avo` avocado · `toasty` buttered toast · `boba` milk tea

Wave 3: `bao` steamed bun · `cocoa` hot cocoa · `jelly` jellyfish ·
`dino` baby dino · `prickle` potted cactus · `zesty` lemon ·
`nigiri` salmon sushi · `tuck` turtle · `dot` ladybug · `scoop` ice cream ·
`pumpkin` pumpkin · `goldie` goldfish

## 3. Construction system (for future additions / QA)

Every avatar is a single self-contained SVG, no external refs, no ids except
where noted:

- **Tile:** `viewBox="0 0 64 64"`, background `<rect width=64 height=64 rx=16>`
  in a per-character pastel. UI may re-crop (public pages render them
  **circle-cropped**), so nothing critical sits in the corners.
- **Face system** (shared with brand motifs, `kfaceStr` in `motifs.jsx`):
  a group `translate(cx cy) scale(s)` containing
  - eyes: circles `r=2` at `x=±5.5` in the character's ink color, each with a
    white highlight `r=0.7` offset `(-0.7,-0.7)`
  - smile: `M-3.2 3.6 Q0 6.6 3.2 3.6`, ink stroke, `stroke-width=1.7`, round cap
  - blush: ellipses `rx=2.6 ry=1.6` at `(±9.2, 3.2)`, `opacity=.75`
  - sleepy variant (used by `sunny`): eyes become arcs
    `M-7.3 .4 Q-5.5 -1.9 -3.7 .4` (and mirror), same stroke as smile.
- **Face scale** ranges 0.55 (small heads: shelly, avo pit) to 0.95 (full-face
  characters). Keep ≥0.55 or eyes get muddy at 30px.
- **Themed features:** some characters replace the smile with species features
  built from the same vocabulary — beak ellipse (`ducky`, `waddle`), owl eyes
  (white `r≈4.8` + ink pupil, `hoot`), muzzle + nose + smile (`honey, pup,
  kit, hammy`), w-mouth (`sealie, hammy`), patch eyes (`bamboo`). Eyes always
  keep the white highlight; blush is always present.
- **Color rules:** background is a desaturated pastel of the body hue family;
  ink is a dark tone of the body hue (never pure black — `bamboo`/`dot` use
  `#4a4a52`); blush is a pink/peach tuned to sit on the body fill.
  No gradients, no strokes thinner than 1, no filters.
- **One clipPath exception:** `bumble.svg` uses `<clipPath id="bzb">` for its
  stripes. If inlining multiple avatars into one DOM, keep ids unique.

### Palette table (bg / ink / blush)

| name | bg | ink | blush |
|---|---|---|---|
| peachy | #ffeae0 | #7a4a30 | #f78ba8 |
| ducky | #fff3cf | #6b5230 | #f6a8c4 |
| honey | #f9ecd7 | #6b4a2a | #f5a9a0 |
| tako | #ffe7ea | #8a4458 | #f2789e |
| waddle | #e3eef8 | #26334a | #f7a8b8 |
| sealie | #e4f1f6 | #5a7080 | #f7b1c8 |
| lottie | #fdeaf2 | #8a4a5e | #ee6f9c |
| bumble | #eaf2fb | #6b5230 | #f7b1c8 |
| flan | #f9ecdb | #7a5a32 | #f5a9b8 |
| dango | #f8efdd | #8a6d5a | #f2a3b8 |
| sunny | #fff1d9 | #8a6d3a | #f7bf9e |
| melly | #eaf6e2 | #5f3a44 | #ea6483 |
| pup | #fdf0e6 | #6b4a2a | #f5a9a0 |
| kit | #fdeadd | #6e4226 | #f78ba8 |
| hammy | #f7e3e3 | #6b4a2a | #f78ba8 |
| bamboo | #eef4ec | #4a4a52 | #f7b1c8 |
| hoot | #ece7f7 | #5a4630 | #f0a8a8 |
| puff | #e7eefa | #6d7d9c | #f7b1c8 |
| splash | #ddedf8 | #2f5570 | #f0a3b8 |
| pinchy | #e2f2ea | #7c3a30 | #ffbdae |
| shelly | #f5f0de | #5d6e4e | #f3b8c5 |
| avo | #eef5e0 | #5f3d1e | #f5a9a0 |
| toasty | #f6e9d2 | #8a6338 | #f5a9a0 |
| boba | #f6e8ee | #8a5a40 | #f2a3b8 |
| bao | #efe9f4 | #8a6a52 | #f5a9b8 |
| cocoa | #ede2da | #6e3826 | #ffb8a0 |
| jelly | #e0f2f0 | #5a4a82 | #f0a3c8 |
| dino | #e4f0d3 | #2f5e4a | #f7b1c8 |
| prickle | #fbe5d3 | #4a6e38 | #f2a3b8 |
| zesty | #eaf2d8 | #8a6d2a | #f7ab8f |
| nigiri | #f2ede4 | #7c4028 | #ffb9a5 |
| tuck | #e7f2dc | #4a6e42 | #f3b8c5 |
| dot | #fbeed6 | #4a4a52 | #ffb8a8 |
| scoop | #fdeaf0 | #8a4a62 | #f2789e |
| pumpkin | #f6e7cf | #7a4a26 | #ff9d7e |
| goldie | #e9f4fa | #8a4a28 | #f78ba8 |

## 4. Code integration

The avatar name lists are hardcoded in three places. Append the 36 new names
(recommended order: keep the original 12 first, then waves 1→3 as listed in
§2, so existing users' picks keep their grid position):

1. **Dashboard picker** — `dash-app.jsx`, `const AVATARS = [...]`
   (grid `auto-fill minmax(54px,1fr)`; 48 tiles ≈ 6 rows — fine as-is, no
   pagination needed, but keep the section collapsed by default as today).
2. **Page builder header/hero picker** — `builder-blocks.jsx`,
   `const BUILDER_AVATARS = [...]`. NOTE: the builder inspector currently
   shows `BUILDER_AVATARS.slice(0, 8)` in the compact row — replace the
   slice with a "more…" disclosure or a scrollable row rather than slicing,
   otherwise new avatars are unreachable there.
3. **Admin** — `admin-ui.jsx` `Avatar` component renders by
   `user.avatar` name; no list change needed, but seed/fixture data may now
   use any of the 48 names.

**DB / API:** avatar tokens remain `set:<name>` — extend the allowed-value
validation list to the 48 names. No schema change.

**Rendering rules (unchanged):** `alt=""` (decorative), `loading="lazy"` in
lists, circle-crop on public profile pages, square radius-14/18 elsewhere.

## 5. QA checklist

- [ ] All 48 render in the dashboard picker; selected state ring visible on
  every background tint (3px accent-deep ring per v1 spec).
- [ ] Public page circle-crop doesn't clip anything important (all faces are
  centered within radius ~13 of tile center; `prickle`'s pot and `scoop`'s
  cone tip get cropped — intended).
- [ ] 30×30 admin size: faces still legible (smallest faces: shelly, avo,
  tuck, nigiri).
- [ ] No duplicate SVG `id` collisions if avatars are ever inlined
  (only `bumble` has an id: `bzb`).
